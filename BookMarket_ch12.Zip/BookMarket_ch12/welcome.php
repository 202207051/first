<!doctype html>
<html class="h-100" >
<head>    
    <title>Welcome</title>
    <link href="https://getbootstrap.com/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet">     
    <style>
        /* 도서 이미지 크기 조절 */
        .book-thumbnail {
            width: 50% !important; /* 이미지 크기를 절반으로 */
            height: auto; /* 비율 유지 */
            display: block; /* 중앙 정렬을 위해 블록 요소로 만듦 */
            margin: 0 auto; /* 중앙 정렬 */
        }
        /* 각 도서 항목의 최소 너비를 설정하여 너무 작아지지 않게 방지 */
        .book-item-col {
            min-width: 150px; /* 각 도서 아이템의 최소 너비 설정 (조절 가능) */
            padding: 10px; /* 패딩 추가 */
        }

        /* 판매중인 도서 섹션 스타일 */
        .selling-books-header {
            background-color: #f8f9fa; /* 밝은 회색 배경 (Bootstrap의 bg-light와 유사) */
            padding: 15px 20px; /* 내부 여백 */
            border-bottom: 1px solid #dee2e6; /* 아래쪽 테두리 */
            margin-bottom: 20px; /* 아래쪽 마진 */
            text-align: center; /* 텍스트 중앙 정렬 */
            font-size: 1.5rem; /* 글자 크기 */
            font-weight: bold; /* 글자 굵기 */
            color: #343a40; /* 글자색 */
            border-radius: .3rem; /* 살짝 둥근 모서리 */
        }
    </style>
  </head>
<body class="d-flex flex-column h-100">
   
<?php
    require "./model.php"; 
    require "./menu.php";
?> 

<?php
     $greeting = "도서 쇼핑몰에 오신 것을 환영합니다";
     $tagline = "Welcome to Web Market!";
?>  

<br>
<main>
    <div class="container py-5">
        
        <div class="p-5 mb-4 bg-body-tertiary rounded-3">
            <div class="container-fluid py-5">
                <h1 class="display-5 fw-bold"><?php echo $greeting ?></h1>
                <p class="col-md-8 fs-4">BookMarket</p>
            </div>
        </div> 

        <div class="row align-items-md-stretch text-center">
            <div class="col-md-12">
                <div class="h-100 p-5">
                    <h2><?php echo $tagline ?></h2>
                    </div>
            </div>
        </div>
        
        <br>

        <div class="selling-books-header">
            판매중인 도서
        </div>

        <div class="row flex-nowrap overflow-auto py-3" style="white-space: nowrap;"> 
        <?php
             $listOfBooks = getAllBooks();
             if (!empty($listOfBooks)) {
                 foreach ($listOfBooks as $id => $book) {
         ?>
                   <div class="col-md-2 col-sm-3 col-xs-4 book-item-col"> 
                     <div class="h-100 p-3 border rounded">
                      <a href="book.php?id=<?php echo $id; ?>"> 
                       <img src ="./resources/images/<?php echo $book['filename']; ?>" class="book-thumbnail" alt="<?php echo $book['name']; ?>">
                      </a>      
                       <h5 class="mt-2 text-truncate"><?php echo $book["name"]; ?></h5> 
                       <p class="text-muted small"><?php echo $book["author"]; ?></p> 		 
                       <p><b>가격:</b> <?php echo number_format($book["unitPrice"]); ?>원</p> 
                       <p><a class="btn btn-sm btn-secondary" href="./book.php?id=<?php echo $id; ?>">상세 &raquo;</a></p> 
                     </div>     
                   </div>
         <?php
                 }
             } else {
                 echo "<p class='text-center'>등록된 도서가 없습니다.</p>";
             }
         ?>
         </div>
         
         <br> <div class="text-center mt-4 mb-3">
            <?php
                date_default_timezone_set("Asia/Seoul");
                echo "현재 접속 일시 : ". date("Y/m/d H:i:s");
            ?>
         </div>

    </div>     
</main>
<?php     
    require "./footer.php";
?>
</body>
</html>