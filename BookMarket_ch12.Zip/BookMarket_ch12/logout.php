<?php
session_start();
session_unset(); // 모든 세션 변수 제거
session_destroy(); // 세션 파괴

header("Location: welcome.php"); // 로그아웃 후 welcome 페이지로 리다이렉션
exit();
?>